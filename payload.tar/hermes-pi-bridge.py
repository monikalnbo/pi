#!/usr/bin/env python3
"""Hermes <-> pi MCP bridge (server side, 24/7) — v2.
Exposes Hermes MCP (hermes mcp serve, stdio) over HTTP on 127.0.0.1:8767.
Accepts NDJSON batch (initialize + initialized + tools/list + calls in ONE
POST body), pipes the whole thing through ONE `hermes mcp serve` process,
returns all JSON-RPC responses concatenated (NDJSON).
pi connects via mcp.json: {"hermes": {"url": "http://127.0.0.1:8767"}}
"""
import subprocess
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HERMES = ["hermes", "mcp", "serve"]
LOG = open("/root/.pi/agent/hermes-bridge.log", "a", buffering=1)


class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def do_POST(self):
        length = int(self.headers.get("Content-Length", 0))
        body = self.rfile.read(length)
        try:
            proc = subprocess.Popen(HERMES, stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
            # feed the entire NDJSON batch, close stdin, collect everything
            out, _ = proc.communicate(body, timeout=180)
            self.send_response(200)
            self.send_header("Content-Type", "application/x-ndjson")
            self.send_header("Content-Length", str(len(out)))
            self.end_headers()
            self.wfile.write(out)
            LOG.write(f"[http] req={body[:300]!r}\n[http] resp={out[:300]!r}\n")
        except Exception as e:
            msg = f'{{"jsonrpc":"2.0","id":null,"error":{{"code":-32603,"message":"{type(e).__name__}"}}}}'.encode()
            self.send_response(502)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(msg)))
            self.end_headers()
            self.wfile.write(msg)

    def log_message(self, *a):
        pass


if __name__ == "__main__":
    srv = ThreadingHTTPServer(("127.0.0.1", 8767), Handler)
    print("hermes-pi MCP bridge v2 on http://127.0.0.1:8767/ (POST NDJSON batch)")
    LOG.write("=== bridge v2 started ===\n")
    srv.serve_forever()
