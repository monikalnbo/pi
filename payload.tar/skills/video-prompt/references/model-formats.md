# 其他模型格式：Veo3 JSON / 英文时间戳式 / Mx-Shell 按秒切片

## 一、Veo3 / Veo3.1 · JSON 结构化格式

Veo3 原生支持音轨（音乐/环境声/音效/对白），社区主流写法是 JSON 分字段。完整骨架：

```json
{
  "shot": {
    "composition": "wide establishing shots transitioning to medium orbit and macro close-up",
    "lens": "24mm for wide interior, 50mm for orbit, 90mm macro for device",
    "frame_rate": "30fps standard with subtle ramping during gesture moments",
    "camera_movement": "smooth orbital tracking around subject, gentle push-in for close-up"
  },
  "subject": {
    "description": "androgynous individual interacting with futuristic home interface",
    "wardrobe": "monochromatic high-tech loungewear with subtle metallic textures",
    "props": "transparent ripple-reactive interfaces, glass-like control device"
  },
  "scene": {
    "location": "suspended apartment overlooking neon cyberpunk cityscape",
    "time_of_day": "twilight",
    "environment": "minimalist architecture with panoramic windows, glowing neon haze outside"
  },
  "visual_details": {
    "action": "gestures in air controlling environment, responsive lighting, final close-up of device",
    "special_effects": "holographic UI, liquid ripple transitions, adaptive lighting",
    "hair_clothing_motion": "minimal motion, soft fabric flow with elegant gesturing"
  },
  "cinematography": {
    "lighting": "ambient interior glow with reactive accents, neon reflections",
    "color_palette": "cool cyans, deep purples, soft whites with glass highlights",
    "tone": "elevated, futuristic, serene"
  },
  "audio": {
    "music": "ambient synthwave with digital chimes and subtle builds",
    "ambient": "soft city hum, electronic interface whispers",
    "sound_effects": "gesture-triggered whooshes, soft chime on logo",
    "mix_level": "refined spatial mix with immersive clarity"
  },
  "dialogue": {
    "character": "",
    "line": "",
    "subtitles": false
  }
}
```

要点：
- `lens` 写真实焦段组合（24mm 广角 / 50mm 标准 / 90mm 微距），比"长焦"有效
- `dialogue.subtitles` 显式声明 false，防止画面乱出字幕
- 每个字段都是一句可执行的描述，不堆形容词

## 二、英文时间戳段落式（可灵 / 海螺 / Seedance 英文写法 / 通用）

来自 awesome-seedance 的电影级实战格式：

```
Style: IMAX 70mm Film, Denis Villeneuve Style, Gritty Realism, Epic Scale, Desaturated.
Duration: 15s.

[00-05s] Shot 1 (The Scale). Extreme Wide Shot. A colossal sandstorm, miles high,
swallows a vast desert landscape. A tiny convoy of armored vehicles races away from
it. The scale of nature vs man is terrifying. Hans Zimmer style tension.

[05-10s] Shot 2 (The Panic). Cockpit Cam. The pilot screams "GO! GO!" (Subtitle:
MAX POWER!). Camera shakes violently. Sand blasts the windshield.

[10-15s] Shot 3 (The Climax). The rover hits a massive dune and launches into the
air (Slow Motion). Silhouette against the dark storm. Lightning strikes within the
dust cloud. Cut to black on impact.
```

规律：
1. **Style 头**：一行风格标签（胶片规格 + 导演风格 + 色调）
2. **Duration**：总时长
3. **每镜头一段**：`[起-止s] Shot N (镜头叙事名)` + 景别/机位 + 画面内容 + 对白/音效提示
4. **给镜头起叙事名**（The Scale / The Panic / The Climax）——有效控制节奏和情绪曲线
5. 对白用引号，字幕提示写 `(Subtitle: …)`

注意：时间戳写法对 Veo3/Sora 效果好；Seedance 中文场景更推荐 `镜头N` 不带秒数（见 seedance.md）。

## 三、Mx-Shell 按秒切片（单镜头一镜到底：变身/充能/ASMR）

### 5 段式结构（顺序不要乱）

```
1. 核心主题       ← 一行 tag 定调
2. 人物与基础设定 ← Who & What is wearing（面部/服装/场景 三行）
3. 氛围与画质     ← 模拟真实摄影机 + 镜头参数
4. 运镜规则       ← 单镜头 / 角度 / 呼吸感
5. 分镜（时间轴） ← 按秒或按镜头展开
```

### 段 1 · 核心主题（3-6 个标签，画面类型→题材→美学层层递进）

```
核心主题：写实暗黑特摄 | BLACK SUN美学 | 破碎肉身 | 战损变身 | 末日战场
核心主题：原子朋克 | 末日丧尸 | 电影级质感 | 超写实 | 杜绝游戏 CG 感
```
关键词库：真实感锚点（电影级质感、超写实、真人实景拍摄、杜绝游戏 CG 感）｜美学定调（暗黑写实、原子朋克、蒸汽朋克、赛博朋克、废土工业、复古港风）｜题材｜情绪

### 段 2 · 人物与基础设定

```
【人物与基础设定】
面部：参照上传图片，五官、脸型、发型百分百还原，杜绝美化。面部伤口、纱布、
      血渍保持一致。表情全程阴郁，变身瞬间眉心仅轻微蹙起，拒绝昂扬斗志。
服装：哑光黑色皮质长风衣，金属腰带为哑光质地，腰带核心为暗红色水晶。
场景：末日战场，微风，硝烟弥漫，阴天荒野，灰蓝色调天空，陨石划过。
```
要点：**"杜绝美化"**（真实感来自瑕疵）；服装写质地；场景写动态环境。

### 段 3 · 氛围与画质（模拟真实摄影机）

```
【氛围与画质】
视觉基调：变形宽荧幕电影质感。模拟 IMAX 胶片摄影机，搭配 Panavision C 系列
        镜头（焦段 35mm，光圈 f4）。
色彩与影调：低饱和灰蓝主调。暗部信息压缩，保留细节。
```

### 段 4 · 运镜规则（三行：单镜头/角度/呼吸感）

```
【运镜规则】
单镜头：一镜到底，无剪辑。
角度：开场仰拍，人物半身左侧面 30 度；变身时极缓环绕至正面平视；完成后
     环绕至右侧面俯拍。
呼吸感：手持拍摄，全程保持极其轻微的、如呼吸般的镜头浮动，增强临场感。
```
"呼吸感"几乎必写——轻微抖动避免 CG 僵直镜头。节奏词：极缓 / 匀速 / 突然 / 应激性 0.1 秒微颤 / 极慢动作。

### 段 5 · 分镜时间轴（两种写法）

**写法 A：按秒切片**（一镜到底）——每段三件套：动作 + 镜头 + 特效，可选"声音/面部"：

```
0-3秒 · 凝视
动作：主角略微低头，目光锁定腰带，脊背紧绷。右手缓慢抬起，握住腰带主体。
镜头：极缓向前推进，捕捉身体因呼吸产生的微幅起伏。
特效：整颗眼球骤然亮起白金色光芒，眼眶周围皲裂，炫光使镜头产生光斑。

3-6秒 · 启动
声音：低语「HENSHIN」。
动作：手掌用力按压腰带核心，水晶被挤压开裂，红光随裂纹亮起。
镜头：低频嗡鸣由远及近，镜头产生应激性 0.1 秒微颤。
```

**写法 B：按镜头切片**（多镜头剪辑）——每镜四件套：景别/构图/运镜手法/画面内容：

```
分镜一：
景别：中景，拍摄机器人腿部以上。
构图：机器人背影居中，背景左侧落地窗，右侧吧台。
运镜手法：跟随运动拍摄。
画面内容：机器人背对镜头向前移动，潇洒转身作为舞蹈 END 动作，led 显示器
         保持绿色微笑。片刻后画外传来玻璃碎裂声，机器人受惊后撤半步，
         led 瞬间切换至黄色害怕表情。
```

## 四、可灵（Kling）补充要点

- 可灵对中文支持好，直接用中文 8 要素 + `镜头N` 分镜即可
- 首尾帧控制是可灵强项：描述强调"起始帧…结束帧…"的连续动作过程
- 大动作（打斗/奔跑）拆成多个 5s/10s 片段分段生成再剪辑，不要塞进一个镜头
- 负面提示词栏单独填：水印、变形、多余手指、文字、logo
