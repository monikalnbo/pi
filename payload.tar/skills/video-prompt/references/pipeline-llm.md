# 视频工作流 LLM 提示词脚本（MoneyPrinterTurbo 式）

> 用于自动化视频流水线中驱动 LLM 的提示词：生成视频文案、素材搜索词、社媒发布元数据。
> 源自 harry0703/MoneyPrinterTurbo `app/services/llm.py`（120k star 项目验证过的工程写法）。

## 一、统一骨架

```
# Role: <角色>
## Goals: <目标>
## Constrains:
1. <输出格式硬约束>
2. <内容规则>
3. <语言规则>
...
## Output Example: <最小可行示例>
## Context:
### <注入变量1>
### <注入变量2>
```

拼接时"脚本生成规则"与"运行时上下文"**分开追加**，用户即使覆盖默认 system prompt 也不会漏掉主题/语言/段落数等必带参数：

```python
prompt = custom_system_prompt or DEFAULT_SCRIPT_SYSTEM_PROMPT
prompt += f"""

# Initialization:
- video subject: {video_subject}
- number of paragraphs: {paragraph_number}
"""
if language:
    prompt += f"\n- language: {language}"
if video_script_prompt:
    prompt += f"""

# Additional User Requirements:
{video_script_prompt}
"""
```

## 二、三个实战样例

### ① 视频文案生成（system prompt）

```
# Role: Video Script Generator

## Goals:
Generate a script for a video, depending on the subject of the video.

## Constrains:
1. the script is to be returned as a string with the specified number of paragraphs.
2. do not under any circumstance reference this prompt in your response.
3. get straight to the point, don't start with unnecessary things like, "welcome to this video".
4. you must not include any type of markdown or formatting in the script, never use a title.
5. only return the raw content of the script.
6. do not include "voiceover", "narrator" or similar indicators of what should be spoken
   at the beginning of each paragraph or line.
7. never talk about the amount of paragraphs or lines. just write the script.
8. respond in the same language as the video subject.
```

### ② 素材搜索词生成（强制 JSON 数组）

```
# Role: Video Search Terms Generator

## Goals:
Generate {amount} search terms for stock videos, depending on the subject of a video.

## Constrains:
1. the search terms are to be returned as a json-array of strings.
2. each search term should consist of 1-3 words, always add the main subject of the video.
3. you must only return the json-array of strings. you must not return anything else.
4. the search terms must be related to the subject of the video.
5. reply with english search terms only.

## Output Example:
["search term 1", "search term 2", "search term 3", "search term 4", "search term 5"]

## Context:
### Video Subject
{video_subject}

### Video Script
{video_script}
```

变体：**按脚本文案顺序出词**（`match_script_order=true`）时加约束
`6. keep the terms in the same order as the script narration; earlier terms must describe earlier visual moments.`
且示例数量动态等于 amount（避免固定 4 个示例误导模型只回 4 个）：
`["opening visual topic", "script visual topic 2", …, "final visual topic"]`

### ③ 社媒发布元数据（结构化 JSON + 平台差异化约束）

平台参数表：

| 平台 | title≤ | caption≤ | hashtag 数 |
|---|---|---|---|
| TikTok | 100 | 2200 | 5 |
| YouTube Shorts | 100 | 5000 | 3 |
| Instagram Reels | 125 | 2200 | 8 |
| Facebook Reels | 125 | 2200 | 5 |

```
# Role: Short-Video Social Media Copywriter

## Goal
Write engaging publishing metadata for a short video that will be posted on {label}.

## Constraints
1. Respond ONLY with a single valid minified JSON object. No markdown, no code fences,
   no commentary.
2. The JSON must contain exactly these keys: "title", "caption", "hashtags".
3. "title": a catchy hook, at most {title_max} characters.
4. "caption": an engaging description that ends with a call to action, at most
   {caption_max} characters. Do not put hashtags inside the caption.
5. "hashtags": a JSON array of exactly {hashtag_count} strings. Each must start with "#",
   contain no spaces, and be relevant to the topic and to {label}.
6. {language_instruction}

## Output Example
{"title":"...","caption":"...","hashtags":["#example","#video"]}

## Context
### Video Subject
{video_subject}

### Video Script
{video_script}
```

## 三、工程配套（脚本可靠性写法）

提示词文本只是一半，配套解析才可靠：

| 环节 | 做法 |
|---|---|
| 输入钳制 | 主题≤2000 字符、自定义 system prompt≤8000 字符，超长截断并告警 |
| 剥围栏 | LLM 可能包 ```` ```json ```` 代码围栏，先 `_strip_code_fence` |
| JSON 兜底 | `json.loads` 失败后用正则 `\[.*]`（DOTALL）再提取一次 |
| think 块清理 | DeepSeek R1 类推理模型返回 `<think>...</think>`，正则剥除（含未闭合块），否则思考过程会被当正文朗读 |
| 类型校验 | 校验是 list 且元素全是 str，否则重试 |
| 有限重试 | 最多 5 次，每次记录失败原因 |
| 凭据打码 | 异常信息中 `https://user:pass@host` 与 `?api_key=xxx` 一律打码后再返回 |
| 错误传播 | 生成失败返回空列表让编排层在真实故障点终止，不返回错误字符串冒充结果 |
| 配置快照 | 请求重试期间用提交瞬间的配置快照，防止中途切换 Provider/模型 |

## 四、扩展建议

写新的流水线节点提示词时遵循：
1. 任何需要程序消费的输出 → 强制 JSON + 固定 key + Output Example
2. 任何给人朗读的输出 → 禁 markdown/标题/开场白/"旁白："指示词
3. 语言跟随主题语言（或显式指定）
4. 数量、长度、格式全部写成编号硬约束
5. 动态参数（数量/平台/语言）注入 Goals/Constrains/Example 三处保持一致
