---
name: rust-galgame-engine
description: 《第八个夏天》自建 Rust+SDL2 galgame 引擎的编码规范与 API 陷阱。凡在 /root/galgame 下写 Rust 代码、改 engine-rs、编译报错、做渲染/文字/剧本解释器/存档功能、跑 xvfb 验收时必须加载。
---

# 《第八个夏天》Rust 引擎编码规范

适用仓库：`/root/galgame`（engine-rs/ = 引擎源码，docs/20 = 规格书，docs/21 = 剧本任务书，docs/22 = 交接总览）。

## 一、硬规则（用户拍板，不可违背）

0. **编码四律（Karpathy+Ponytail，2026-09-07 增）**：①先想后写，假设说出来；②简单至上——200 行能 50 行就重写，单实现不建接口，不为「以后」搭脚手架；③外科手术式修改——只动必须动的，不顺手「改善」无关代码；④每步有可验证标准。**调试铁律：没找到根因禁止修复**——先建能红能绿的紧反馈循环（日志探针/最小重现），再动手。纯逻辑模块（expr/lexer/layout/slots）先补单测再改。已知简化的天花板用 `// ponytail:` 注释标记。
1. **全模块化**：每个文件单一职责、百行量级，禁止死大文件。新功能=新模块，方便定位。目录：`gfx/`（渲染）、`text/`（字体断行打字机）、`script/`（剧本语法体系）、`ui/`（theme/geom/widgets+各界面）、`save/`（存档）、`audio/`、`platform.rs`（Windows/Linux gating）、`systems.rs`（L1 系统动作）
2. **文件名全英文**，代码注释可中文，报错文案必须中文（含资源名+剧本行号）
3. **主循环在 app.rs**：事件路由→InputRouter/Overlay/Systems/Interp；main.rs 保持 ~15 行
4. 每步完成：xvfb+截图+VLM+像素交叉验证 → 通过才 commit+push；新错误记 `docs/11_错题本.md`（游戏仓）

## 二、渲染架构（不要改动）

- 逻辑分辨率 1280×720（config.rs 常量），窗口 letterbox 16:9 居中黑边
- 整帧画进离屏纹理 `screen`，再贴窗口；越界层（reach）直接画窗口坐标突破黑边（预留于 present_frame 内 present 之前）
- 图片统一 1280×720 画布整幅 blit（背景 JPG/立绘 PNG/CG）
- 立绘 PNG 必须 `set_blend_mode(BlendMode::Blend)` 才能透明合成

## 三、rust-sdl2 0.37 实测陷阱（错题本级）

1. **`Sdl2TtfContext::load_font_at_index(path, index, point_size)` 参数顺序与 C API 相反**！C 是 (path, ptsize, index)，rust 是 (path, **index**, **point_size**)，类型 (P, u32, u16)。传反了报 "Couldn't load font file"（面号超范围）
2. **render target 是闭包式**：`canvas.with_texture_canvas(&mut tex, |tc| {...})`，没有裸 set_render_target
3. `Rect.height`/`.width` 是方法不是字段（TextureQuery 才是字段）
4. 无 GPU（xvfb）时 `accelerated()+present_vsync()` 建 canvas 会失败 → 必须回退 `software()`
5. TTC 字体面序：Noto CJK .ttc 中 SC=索引2；用 `face_family_name()` 探测，勿硬编码
6. 本机完整字体：`/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc`；Windows 用 `msyh.ttc`；兜底 `game/data/system_polyfill/font.ttf`（子集，玩家输入名可能缺字，仅兜底）

## 四、验收循环（SDL 程序）

```bash
cd /root/galgame && xvfb-run -a -s "-screen 0 1280x800x24" bash -c '
  ES_DEBUG_AUTOCLICK_MS=900 ./engine-rs/target/release/eighth-summer & P=$!
  sleep 2   # 注意：软件渲染首帧慢，截图前 sleep≥2s，太早截到黑屏
  ffmpeg -y -loglevel error -f x11grab -video_size 1280x800 -i "$DISPLAY" -frames:v 1 /tmp/shot.png
  kill $P 2>/dev/null; wait $P 2>/dev/null'
python3 tools/vlm_q.py /tmp/shot.png      # VLM 是眼睛不是法官
# 关键结论（黑边/颜色/位置）用 PIL 像素级交叉验证
```

- 程序内交互验收用环境变量 `ES_DEBUG_AUTOCLICK_MS=<ms>`（自动点击），不要覆盖正式文件
- 720 以下/左右应是纯黑 letterbox（PIL 行均值=0 验证）

## 五、剧本语法体系（A3 实现，script/ 模块）

指令集 26 条见 docs/20 第四节（bg/char/n/name/flag/set/jump/if/choice/input/meta_*/reach/window_fx/shutdown/end…）。三层：lexer（行类型+`|`参数）→ command（指令枚举+校验，一处看全语法）→ interp（执行调度）。变量 f.*（随存档）/sf.*（global.json 退出即写盘）。

## 六、流程

开工先读 docs/22 交接总览 → 按任务顺序（A 引擎→B 剧本）→ 遇错先查 docs/09+11 → 修完记录 → 每步 commit+push（信息中文）。批量生图先报数量。
