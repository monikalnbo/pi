---
name: x-twitter
description: "接管 X/Twitter：用 bb-browser 复用真实 Chrome 登录态自动发推、删推、搜索、刷时间线，零 API key。当用户提到推特、X、Twitter、发推、推文、tweet 时加载本技能。"
---

# X/Twitter 自动化工作流（bb-browser）

本机已固化的工作流：复用真实 Chrome 的登录态（用户已在浏览器中手动登录 X），通过自定义 adapter 直接调用 GraphQL 接口发帖/删帖。**不需要任何 API key**。

## 前置条件检查

按顺序执行，任何一步失败先修复再继续：

```bash
# 1. CDP 浏览器是否在线（Chrome 调试端口 9222）
curl -s --max-time 5 http://127.0.0.1:9222/json/version

# 2. daemon 状态
bb-browser daemon status
```

### 启动方式（如果没在运行）

Chrome 必须以调试端口启动并复用已有登录态 profile：

```bash
# 有显示器/X 环境时：
/root/.bb-browser/browser/chrome-linux64/chrome \
  --user-data-dir=/root/.bb-ui-profile --no-sandbox --disable-gpu \
  --disable-dev-shm-usage --remote-debugging-port=9222 \
  --window-size=1440,900 https://x.com/home &

# 无头服务器（无 X）：先套 xvfb-run
xvfb-run -a /root/.bb-browser/browser/chrome-linux64/chrome \
  --user-data-dir=/root/.bb-ui-profile --no-sandbox \
  --remote-debugging-port=9222 https://x.com/home &

# 然后启动 daemon
bb-browser daemon start
```

关键点：
- **profile 固定为 `/root/.bb-ui-profile`**，X 的登录态永久保存在里面，重启不用重新登录。
- 如果登录态失效（adapter 返回 "No ct0 cookie"），需要让用户在浏览器里重新手动登录一次。

## 核心命令

⚠️ **每条命令都必须带 `--port 9222`**（或在命令前 `export BB_BROWSER_CDP_URL=http://127.0.0.1:9222`），否则报 "Cannot find a Chromium-based browser"。

### 发推（写操作，谨慎！）

```bash
bb-browser --port 9222 site twitter/post "推文内容"
# 回复某条推文：
bb-browser --port 9222 site twitter/post "内容" --args '{"reply_to":"推文ID"}'
```

- adapter 位置：`~/.bb-browser/bb-sites/twitter/post.js`
- **字数限制：280 加权字符，中文/全角每字算 2**（adapter 内置预检）。
- 成功返回含 `posted: true` 和推文 ID；把推文链接 `https://x.com/<用户名>/status/<ID>` 给用户。

### 删推

```bash
bb-browser --port 9222 site twitter/delete <推文ID>
```

### 只读操作（社区自带 adapter）

```bash
bb-browser --port 9222 site twitter/search "关键词"
bb-browser --port 9222 site twitter/user <用户名>   # 注意：此 adapter 只返回用户ID，字段不全，属已知问题
bb-browser --port 9222 site twitter/tweets <用户名> # 时间线
bb-browser --port 9222 site twitter/thread <推文ID>
bb-browser --port 9222 site twitter/notifications
bb-browser --port 9222 site info <name>      # 查看某 adapter 用法
```

已实测可用（2026-08-24）：search、notifications 返回完整数据；登录态有效。

## 安全规则（必须遵守）

1. **发推是真实的公开写操作**。除非用户的指令本身就是明确要发的内容（如“发个推：xxx”），否则先把拟发的文案给用户确认。
2. 不要未经确认批量发推、点赞、关注。
3. 绝不读取或输出 `~/.xurl`、cookie 内容等凭据。

## 踩坑记录（重要，避免重复踩坑）

- **不要走 UI 模拟发帖**（open compose → fill → click）。脆弱且容易丢草稿；CJK 输入有字数陷阱。直接用 `twitter/post` adapter。
- **如果遇到 "daily limit (344)" 报错**：大概率不是真限额，而是请求缺 `X-Client-Transaction-Id` 被风控软拒。当前 post.js 已带 transaction-id 生成逻辑（依赖同目录 `_helper.js`），正常不会再出现；若出现，先检查 `_helper.js` 是否存在。
- queryId 从页面 webpack 动态解析，不硬编码——X 更新前端不影响 adapter。
- `site update` 可能覆盖社区 adapter 目录，更新后检查 post.js/delete.js 是否还在。

## 完整文档与源码

GitHub fork（分支 `agent-post-workflow`）：https://github.com/monikalnbo/bb-browser
路径 `docs/agent-post-workflow/` 下有完整实战记录、三条路线对比和经验总结。
